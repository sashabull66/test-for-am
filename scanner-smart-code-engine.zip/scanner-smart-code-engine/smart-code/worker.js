/* eslint-disable */

const signature =
    '312dc4f37f2fb11f500770d41e3b760d95c26b07eb51617750f45c6659883ab3a0730d9e729e38d3230918d9baed67886f0643693cab56d891ce73bb832e906a80fa080f8472aac3fb08f77bd6acffb8b7ce47f373c1e08c8e99a41706dbd06e7057aacf1cc3c9b8738a336cf62af809038baf8d80f5504fd3dac19ca6b43faa';

const ctx = self;

const getTextFields = (result) => {
    // vendor have not provided a type for scanned data
    const data = [];
    const co = result.ObjectsBegin();

    for (; !co.Equals(result.ObjectsEnd()); co.Advance()) {
        const code_object = co.GetValue();
        const object_data = { type: code_object.GetTypeStr(), attributes: {} };
        const tf = code_object.FieldsBegin();

        for (; !tf.Equals(code_object.FieldsEnd()); tf.Advance()) {
            // const key = tf.GetKey();
            const code_field = tf.GetValue();
            const code_field_name = code_field.Name();
            let value_binary = '';
            let value_string = '';

            if (code_field.HasBinaryRepresentation()) {
                value_binary = code_field.GetBinaryRepresentation().GetBase64String();
            }

            if (code_field.HasOcrStringRepresentation())
                value_string = code_field.GetOcrString().GetFirstString();

            object_data[code_field_name] = {
                name: code_field_name,
                value_binary,
                value_string,
                isAccepted: code_field.IsAccepted(),
            };
        }
        // attr

        const start = code_object.AttributesBegin();
        const end = code_object.AttributesEnd();

        for (; !start.Equals(end); start.Advance()) {
            const attrKey = start.GetKey();

            const attrValue = start.GetValue();

            object_data.attributes[attrKey] = attrValue;
        }

        data.push(object_data);
    }

    return data;
};

(async () => {
    let engine;
    let session;
    let currentDocType = 'barcode';

    const EngineConfig = {
        mode: 'default',
        signature,
    };

    postMessage({
        requestType: 'wasmEvent',
        data: { type: 'started' },
    });

    let SE;

    const initSmartEngine = async () => {
        ctx.importScripts('./codeengine_wasm.js');

        const wasmFilePath = {
            mainScriptUrlOrBlob: './codeengine_wasm.js',
            locateFile: (file) => `./${file}`,
        };

        return ctx.SmartCodeEngine(wasmFilePath);
    };

    try {
        SE = await initSmartEngine();
    } catch (e) {
        throw new Error('Не удалось проинициализировать SmartEngine');
    }

    try {
        // eslint-disable-next-line new-cap
        engine = new SE.CodeEngine(false);
    } catch (e) {
        postMessage({
            requestType: 'wasmEvent',
            data: {
                type: 'wasmError',
                data: `Create engine error ${SE.printExceptionMessage(e)}`,
            },
        });
        throw new Error(`Create engine ${SE.printExceptionMessage(e)}`);
    }

    async function createSession(docType, isRgba = false) {
        try {
            const sessionSettings = engine.GetDefaultSessionSettings();

            if (
                docType === 'barcode' &&
                engine.IsEngineAvailable(SE.CodeEngineType.CodeEngine_Barcode)
            ) {
                const engineName = SE.ToString(SE.EngineSettingsGroup.Barcode);

                // Setting option to enable barcode recognition
                sessionSettings.SetOption(`${engineName}.enabled`, 'true');
                sessionSettings.SetOption(`${engineName}.COMMON.enabled`, 'true');
                sessionSettings.SetOption(`${engineName}.maxAllowedCodes`, '99');
                sessionSettings.SetOption(`${engineName}.roiDetectionMode`, 'anywhere');
            }

            if (docType === 'mrz' && engine.IsEngineAvailable(SE.CodeEngineType.CodeEngine_MRZ)) {
                const engineName = SE.ToString(SE.EngineSettingsGroup.Mrz);

                // Setting option to enable mrz recognition
                sessionSettings.SetOption(`${engineName}.enabled`, 'true');
            }

            if (
                docType === 'card' &&
                engine.IsEngineAvailable(SE.CodeEngineType.CodeEngine_BankCard)
            ) {
                const engineName = SE.ToString(SE.EngineSettingsGroup.Card);

                // Setting option to enable bank card recognition
                sessionSettings.SetOption(`${engineName}.enabled`, 'true');
            }

            if (
                docType === 'phone' &&
                engine.IsEngineAvailable(SE.CodeEngineType.CodeEngine_CodeTextLine)
            ) {
                // Setting option to enable phone number recognition
                const engineName = SE.ToString(SE.EngineSettingsGroup.CodeTextLine);

                sessionSettings.SetOption(`${engineName}.enabled`, 'true');
                sessionSettings.SetOption(`${engineName}.phone_number.enabled`, 'true');
            }

            sessionSettings.SetOption('global.sessionTimeout', '20.0');

            // images from canvas has RGBA pixel format
            if (isRgba) {
                sessionSettings.SetOption('global.rgbPixelFormat', 'RGBA');
            }

            if (docType) {
                currentDocType = docType;
            }

            session = await engine.SpawnSession(sessionSettings, EngineConfig.signature);

            const activationCode = session.GetActivationRequest();

            postMessage({
                requestType: 'activation',
                code: activationCode,
            });
        } catch (e) {
            let data = e;

            try {
                data = SE.printExceptionMessage(e);
            } catch (error) {
                /* empty */
            }

            // eslint-disable-next-line no-console
            console.error(data);

            postMessage({
                requestType: 'wasmEvent',
                data: { type: 'wasmError', data },
            });
        }
    }

    function resultObject(result, isManuallyUploaded) {
        return {
            isManuallyUploaded,
            requestType: 'result',
            docType: currentDocType,
            data: getTextFields(result),
        };
    }

    function recognizeFile(imageData, isManuallyUploaded) {
        const imgSrc = new SE.seImage(imageData);

        try {
            const result = session.Process(imgSrc);

            const resultMessage = resultObject(result, isManuallyUploaded);

            imgSrc.delete();
            result.delete();

            return resultMessage;
        } catch (e) {
            postMessage({
                requestType: 'activationStatus',
                data: {
                    isActivated: session.IsActivated(),
                },
            });
            const activationCode = session.GetActivationRequest();

            postMessage({
                requestType: 'activation',
                code: activationCode,
            });

            return null;
        }
    }

    const recognizeFileAction = (imageData, isManuallyUploaded) => {
        const resultFile = recognizeFile(imageData, isManuallyUploaded);

        postMessage(resultFile);
    };

    postMessage({
        requestType: 'wasmEvent',
        data: {
            type: 'ready',
            version: SE.CodeEngineGetVersion(),
        },
    });
    ctx.onmessage = async (msg) => {
        switch (msg.data.requestType) {
            case 'file':
                recognizeFileAction(msg.data.imageData, msg.data.isManuallyUploaded);
                break;

            case 'reset':
                session.Reset();
                postMessage({ requestType: 'wasmEvent', data: { type: 'reset' } });
                break;

            case 'activationCode':
                session.Activate(msg.data.code);
                if (session.IsActivated()) {
                    postMessage({
                        requestType: 'activated',
                        data: {
                            version: SE.CodeEngineGetVersion(),
                        },
                    });
                } else {
                    postMessage({
                        requestType: 'activationError',
                    });
                }

                break;

            case 'createSession':
                await createSession(msg.data.data);
                break;
        }
    };
})();
