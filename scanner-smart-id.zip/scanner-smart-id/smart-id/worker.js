/* eslint-disable */

const signature =
    '312dc4f37f2fb11f500770d41e3b760d95c26b07eb51617750f45c6659883ab3a0730d9e729e38d3230918d9baed67886f0643693cab56d891ce73bb832e906a80fa080f8472aac3fb08f77bd6acffb8b7ce47f373c1e08c8e99a41706dbd06e7057aacf1cc3c9b8738a336cf62af809038baf8d80f5504fd3dac19ca6b43faa';

const ctx = self;

function getTextFields(result) {
    const data = {};
    const tf = result.TextFieldsBegin();

    for (; !tf.Equals(result.TextFieldsEnd()); tf.Advance()) {
        const key = tf.GetKey();
        const field = tf.GetValue();
        let value = field.GetValue().GetFirstString();

        if (field.GetBaseFieldInfo().HasAttribute('encoding')) {
            if (field.GetBaseFieldInfo().GetAttribute('encoding') === 'base64') {
                const data = atob(value);
                const { length } = data;
                const bytes = new Uint8Array(length);

                for (let i = 0; i < length; i++) {
                    bytes[i] = data.charCodeAt(i);
                }

                const decoder = new TextDecoder(); // default is utf-8

                value = decoder.decode(bytes);
            }
        }

        data[key] = value;
    }

    return data;
}

(async () => {
    let engine;
    let spawnedSessionRGB;

    const EngineConfig = {
        mode: 'default',
        signature,
        docTypes: '*',
    };

    postMessage({
        requestType: 'wasmEvent',
        data: { type: 'started' },
    });

    let SE;

    const initSmartIdEngine = async () => {
        ctx.importScripts('./idengine_wasm.js');

        const wasmFilePath = {
            mainScriptUrlOrBlob: './idengine_wasm.js',
            locateFile: (file) => `./${file}`,
        };

        return ctx.SmartIDEngine(wasmFilePath);
    };

    try {
        SE = await initSmartIdEngine();
    } catch (e) {
        console.log(e);
        throw new Error('Не удалось проинициализировать SmartIdEngine');
    }

    try {
        engine = new SE.seIdEngine(true, 1, true);
    } catch (e) {
        postMessage({
            requestType: 'wasmEvent',
            data: {
                type: 'wasmError',
                data: `Create engine error ${SE.printExceptionMessage(e)}`,
            },
        });
        throw new Error(`Create engine ${SE.printExceptionMessage(e)}`);
    }

    async function createSession() {
        try {
            const sessionSettings = engine.CreateSessionSettings();

            sessionSettings.SetCurrentMode('anyrus');
            sessionSettings.AddEnabledDocumentTypes('*');

            spawnedSessionRGB = await engine.SpawnSession(sessionSettings, EngineConfig.signature);

            const activationCode = spawnedSessionRGB.GetActivationRequest();

            sessionSettings.SetOption('global.sessionTimeout', '20.0');

            postMessage({
                requestType: 'activation',
                code: activationCode,
            });
        } catch (e) {
            let data = e;

            try {
                data = SE.printExceptionMessage(e);
            } catch (error) {
                /* empty */
            }

            // eslint-disable-next-line no-console
            console.error(data);

            postMessage({
                requestType: 'wasmEvent',
                data: { type: 'wasmError', data },
            });
        }
    }

    function resultObject(result, isManuallyUploaded) {
        return {
            requestType: 'result',
            docType: result.GetDocumentType(),
            data: getTextFields(result),
            isManuallyUploaded,
        };
    }

    function recognizeFile(imageData, isManuallyUploaded) {
        // eslint-disable-next-line new-cap
        const imgSrc = new SE.seImage(imageData);

        try {
            const result = spawnedSessionRGB.Process(imgSrc);

            const resultMessage = resultObject(result, isManuallyUploaded);

            imgSrc.delete();
            result.delete();

            return resultMessage;
        } catch (e) {
            postMessage({
                requestType: 'activationStatus',
                data: {
                    isActivated: spawnedSessionRGB.IsActivated(),
                },
            });
            const activationCode = spawnedSessionRGB.GetActivationRequest();

            postMessage({
                requestType: 'activation',
                code: activationCode,
            });

            return null;
        }
    }

    const recognizeFileAction = (imageData, isManuallyUploaded) => {
        const resultFile = recognizeFile(imageData, isManuallyUploaded);

        postMessage(resultFile);
    };

    postMessage({
        requestType: 'wasmEvent',
        data: {
            type: 'ready',
            version: SE.seIdEngineGetVersion(),
        },
    });
    ctx.onmessage = async (msg) => {
        switch (msg.data.requestType) {
            case 'file':
                recognizeFileAction(msg.data.imageData, msg.data.isManuallyUploaded);
                break;

            case 'reset':
                spawnedSessionRGB.Reset();
                postMessage({ requestType: 'wasmEvent', data: { type: 'reset' } });
                break;

            case 'activationCode':
                spawnedSessionRGB.Activate(msg.data.code);
                if (spawnedSessionRGB.IsActivated()) {
                    postMessage({
                        requestType: 'activated',
                        data: {
                            version: SE.seIdEngineGetVersion(),
                        },
                    });
                } else {
                    postMessage({
                        requestType: 'activationError',
                    });
                }

                break;

            case 'createSession':
                await createSession();
                break;
        }
    };
})();
