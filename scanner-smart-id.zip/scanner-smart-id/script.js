const output = document.getElementById('output');
const copyBtn = document.getElementById('copyBtn');
const pastBtn = document.getElementById('pastBtn');
const pastContentBtn = document.getElementById('pastContentBtn');
const body = document.querySelector('body');
let worker;
let globalDoctype = 'doc';

const markActiveBtn = (doctype) => {
    document.getElementById(doctype).style.backgroundColor = 'green'
}

const killWorker = () => {
    if (worker) {
        worker?.terminate();
        worker = undefined;
    }
}

const convertToByteArray = (base64str) => Uint8Array.from(atob(base64str), (c) => c.charCodeAt(0))

loadFile = (base64str, isManuallyUploaded = false) => {
    try {
        const byteArray = convertToByteArray(base64str);

        worker?.postMessage({
            isManuallyUploaded,
            requestType: 'file',
            imageData: byteArray.buffer,
        });
    } catch (e) {
        console.error(e);
    }
};

const loadImage = (base64str) => {
    loadFile(base64str, false);
}

const uploadPhoto = (base64str) => {
    loadFile(base64str, true);
};

const postMessageToWebkit = (message) => {
    window?.workerLog?.push({info:'Отправка сообщения', payload:message});
    postMessage(message);
    if (window?.webkit?.messageHandlers?.callbackHandler?.postMessage) {
        window.webkit.messageHandlers.callbackHandler.postMessage(message);
    }
};

window.addEventListener('message', (e) => {
    output.innerText = e.data;
});

const createSession = (docType) => {
    worker?.postMessage({
        requestType: 'createSession',
        data: docType,
    });
};

const activate = (code) => {
    try {
        worker?.postMessage({
            requestType: 'activationCode',
            code,
        });
    } catch (error) {
        worker?.postMessage({
            requestType: 'networkError',
            data: {
                type: 'networkError',
                data: JSON.parse(JSON.stringify(error)),
            },
        });
    }
};


pastBtn.addEventListener('click', async () => {
    const code = await window.navigator.clipboard.readText();

    activate(code);
});

pastContentBtn.addEventListener('click', async () => {
    const cnt = await window.navigator.clipboard.readText();

    loadImage(cnt);
});

/**
 * @param doctype 'doc'
 * */
const initSmartCodeEngine = (doctype) => {
    if (!window.workerLog) {
        window.workerLog = [];
    }

    if (doctype) {
        globalDoctype = doctype;
    }

    killWorker();

    markActiveBtn(globalDoctype)

    const initSmartCodeEngineWorker = (type) => {

        window.workerLog.push({ info:`Выполнение createSession с аргументом ${type}`})
        if (type === 'doc') {
            worker = new Worker('./smart-id/worker.js');
        } else {
            window.workerLog.push({ error: `Неверно указан docType. Ожидается "doc" а передан ${type}` })
            return
        }

        worker.onmessage = async (msg) => {
            const resultData = msg.data;

            switch (resultData?.requestType) {
                case 'wasmEvent': {
                    if (resultData.data.type === 'ready') {
                        window.workerLog.push({ info: `wasmEvent c статусом ready. Производится создание сессии с типом ${type}` })

                        createSession(type);
                    }
                    if (['error', 'processError'].includes(resultData.data.type)) {
                        window.workerLog.push({ error: `wasmEvent c ошибкой: ${resultData.data.type}. Производится рестарт worker` })

                        initSmartCodeEngine(globalDoctype);
                    }
                    break;
                }

                case 'result': {
                    if (resultData.isManuallyUploaded && Object.keys(resultData.data).length  === 0) {
                        const result = JSON.stringify({
                            type: 'scannerResult',
                            status: 'result',
                            payload: [],
                        });

                        postMessageToWebkit(result);

                        window.workerLog.push({ info: 'Получен невалидный result после ручной загрузки.' })
                    }

                    if (resultData.data.length) {
                        const result = JSON.stringify({
                            type: 'scannerResult',
                            status: 'result',
                            payload: resultData,
                        });

                        postMessageToWebkit(result);

                        window.workerLog.push({ info: 'Получен успешный result c payload. Производится рестарт worker' })
                        initSmartCodeEngine(globalDoctype);
                    }

                    break;
                }

                case 'activated': {
                    const activationResult = JSON.stringify({
                        type: 'scannerResult',
                        status: 'activationSuccessful',
                        payload: null,
                    });

                    body.style.backgroundColor = 'green'
                    copyBtn.onclick = null
                    copyBtn.style.display = 'none'
                    pastBtn.style.display = 'none'
                    pastContentBtn.style.display = 'block'

                    postMessage(activationResult);
                    postMessageToWebkit(activationResult);

                    break;
                }

                case 'activation': {
                    const activationResult = JSON.stringify({
                        type: 'scannerResult',
                        status: 'activationExpired',
                        payload: resultData?.code,
                    });

                    body.style.backgroundColor = 'red'
                    copyBtn.onclick = () => {
                        window.navigator.clipboard.writeText(resultData?.code);
                    }
                    copyBtn.style.display = 'block'
                    pastBtn.style.display = 'block'
                    pastContentBtn.style.display = 'none'

                    postMessageToWebkit(activationResult);

                    break;
                }
                default:
                    break;
            }
        };
    };

    initSmartCodeEngineWorker(globalDoctype);
};

window.scanner = {
    createSession: initSmartCodeEngine,
    uploadPhoto,
    loadImage,
    activate,
};
